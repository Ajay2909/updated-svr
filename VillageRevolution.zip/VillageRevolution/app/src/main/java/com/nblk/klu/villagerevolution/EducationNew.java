package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class EducationNew {
    String children_attending_sch, sch_gng_children, nprimary_sch, dist_primary_sch;
    String nmiddle_sch, dist_middle_sch, nsec_sch, dist_sec_sch, ncollege, nsnr_sec_sch, adlult_lit_cls, college_avr_range, indstrial_sch, training_sch, othr_sch;

    EducationNew() {

    }

    public EducationNew(String children_attending_sch, String sch_gng_children, String nprimary_sch, String dist_primary_sch, String nmiddle_sch, String dist_middle_sch, String nsec_sch, String dist_sec_sch, String ncollege, String nsnr_sec_sch, String adlult_lit_cls, String college_avr_range, String indstrial_sch, String training_sch, String othr_sch) {
        this.children_attending_sch = children_attending_sch;
        this.sch_gng_children = sch_gng_children;
        this.nprimary_sch = nprimary_sch;
        this.dist_primary_sch = dist_primary_sch;
        this.nmiddle_sch = nmiddle_sch;
        this.dist_middle_sch = dist_middle_sch;
        this.nsec_sch = nsec_sch;
        this.dist_sec_sch = dist_sec_sch;
        this.ncollege = ncollege;
        this.nsnr_sec_sch = nsnr_sec_sch;
        this.adlult_lit_cls = adlult_lit_cls;
        this.college_avr_range = college_avr_range;
        this.indstrial_sch = indstrial_sch;
        this.training_sch = training_sch;
        this.othr_sch = othr_sch;
    }

    public String getChildren_attending_sch() {
        return children_attending_sch;
    }

    public String getSch_gng_children() {
        return sch_gng_children;
    }

    public String getNprimary_sch() {
        return nprimary_sch;
    }

    public String getDist_primary_sch() {
        return dist_primary_sch;
    }

    public String getNmiddle_sch() {
        return nmiddle_sch;
    }

    public String getDist_middle_sch() {
        return dist_middle_sch;
    }

    public String getNsec_sch() {
        return nsec_sch;
    }

    public String getDist_sec_sch() {
        return dist_sec_sch;
    }

    public String getNcollege() {
        return ncollege;
    }

    public String getNsnr_sec_sch() {
        return nsnr_sec_sch;
    }

    public String getAdlult_lit_cls() {
        return adlult_lit_cls;
    }

    public String getCollege_avr_range() {
        return college_avr_range;
    }

    public String getIndstrial_sch() {
        return indstrial_sch;
    }

    public String getTraining_sch() {
        return training_sch;
    }

    public String getOthr_sch() {
        return othr_sch;
    }
}
