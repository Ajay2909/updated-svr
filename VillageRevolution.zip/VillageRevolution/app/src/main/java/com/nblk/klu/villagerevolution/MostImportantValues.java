package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */


public class MostImportantValues {
    String mc1, mc2, mc3;


    MostImportantValues(){

    }

    public MostImportantValues(String mic1, String mic2, String mic3) {
    }

    public String getMc1() {
        return mc1;
    }

    public void setMc1(String mc1) {
        this.mc1 = mc1;
    }

    public String getMc2() {
        return mc2;
    }

    public void setMc2(String mc2) {
        this.mc2 = mc2;
    }

    public String getMc3() {
        return mc3;
    }

    public void setMc3(String mc3) {
        this.mc3 = mc3;
    }
}
