package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class PopulationValues {

    String total_persons, total_males, total_females, sc_persons, sc_males, sc_females, st_persons, st_males, st_females;


    PopulationValues() {

    }

    public PopulationValues(String total_persons, String total_males, String total_females, String sc_persons, String sc_males, String sc_females, String st_persons, String st_males, String st_females) {
        this.total_persons = total_persons;
        this.total_males = total_males;
        this.total_females = total_females;
        this.sc_persons = sc_persons;
        this.sc_males = sc_males;
        this.sc_females = sc_females;
        this.st_persons = st_persons;
        this.st_males = st_males;
        this.st_females = st_females;
    }

    public String getTotal_persons() {
        return total_persons;
    }

    public String getTotal_males() {
        return total_males;
    }

    public String getTotal_females() {
        return total_females;
    }

    public String getSc_persons() {
        return sc_persons;
    }

    public String getSc_males() {
        return sc_males;
    }

    public String getSc_females() {
        return sc_females;
    }

    public String getSt_persons() {
        return st_persons;
    }

    public String getSt_males() {
        return st_males;
    }

    public String getSt_females() {
        return st_females;
    }
}
