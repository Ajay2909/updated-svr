package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/14/2018.
 */

public class Income {
    double inc,expe;

    public Income(){

    }
    public Income(double inc, double expe) {
        this.inc = inc;
        this.expe = expe;
    }
}
