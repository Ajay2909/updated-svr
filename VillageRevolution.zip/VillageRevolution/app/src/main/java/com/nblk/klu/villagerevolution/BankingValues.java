package com.nblk.klu.villagerevolution;

import android.widget.RadioGroup;

/**
 * Created by bhavna on 9/15/2018.
 */

public class BankingValues {
    String  cmbnk,cpbnk;
    RadioGroup cmbg,rg;
    BankingValues(String combank, String coopbank)
    {

    }

    public BankingValues(String cmbnk, String cpbnk, RadioGroup cmbg, RadioGroup rg) {
        this.cmbnk = cmbnk;
        this.cpbnk = cpbnk;
        this.cmbg = cmbg;
        this.rg = rg;
    }

    public String getCmbnk() {
        return cmbnk;
    }

    public String getCpbnk() {
        return cpbnk;
    }

    public RadioGroup getCmbg() {
        return cmbg;
    }

    public RadioGroup getRg() {
        return rg;
    }
}