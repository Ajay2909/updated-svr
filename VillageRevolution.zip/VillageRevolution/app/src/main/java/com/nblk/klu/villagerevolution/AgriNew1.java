package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class AgriNew1 {
    private String forest_land, panchayat_land, government_canals, private_canals, electric_wells, Nonelectric_wells, no_electric_tubewells,
            electric_tubewells, tank, river, lake, waterfalls, others, total_irrigated_area, unirrigated_area, culturable_waste, non_cultivable_area;

    AgriNew1(){

    }

    public AgriNew1(String forest_land, String panchayat_land, String government_canals, String private_canals, String electric_wells, String nonelectric_wells, String no_electric_tubewells, String electric_tubewells, String tank, String river, String lake, String waterfalls, String others, String total_irrigated_area, String unirrigated_area, String culturable_waste, String non_cultivable_area) {
        this.forest_land = forest_land;
        this.panchayat_land = panchayat_land;
        this.government_canals = government_canals;
        this.private_canals = private_canals;
        this.electric_wells = electric_wells;
        Nonelectric_wells = nonelectric_wells;
        this.no_electric_tubewells = no_electric_tubewells;
        this.electric_tubewells = electric_tubewells;
        this.tank = tank;
        this.river = river;
        this.lake = lake;
        this.waterfalls = waterfalls;
        this.others = others;
        this.total_irrigated_area = total_irrigated_area;
        this.unirrigated_area = unirrigated_area;
        this.culturable_waste = culturable_waste;
        this.non_cultivable_area = non_cultivable_area;
    }

    public String getForest_land() {
        return forest_land;
    }

    public String getPanchayat_land() {
        return panchayat_land;
    }

    public String getGovernment_canals() {
        return government_canals;
    }

    public String getPrivate_canals() {
        return private_canals;
    }

    public String getElectric_wells() {
        return electric_wells;
    }

    public String getNonelectric_wells() {
        return Nonelectric_wells;
    }

    public String getNo_electric_tubewells() {
        return no_electric_tubewells;
    }

    public String getElectric_tubewells() {
        return electric_tubewells;
    }

    public String getTank() {
        return tank;
    }

    public String getRiver() {
        return river;
    }

    public String getLake() {
        return lake;
    }

    public String getWaterfalls() {
        return waterfalls;
    }

    public String getOthers() {
        return others;
    }

    public String getTotal_irrigated_area() {
        return total_irrigated_area;
    }

    public String getUnirrigated_area() {
        return unirrigated_area;
    }

    public String getCulturable_waste() {
        return culturable_waste;
    }

    public String getNon_cultivable_area() {
        return non_cultivable_area;
    }
}
