package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */


public class AreaValues {
    String  varea,hhold,hsize,puccahouse,kutchhouse,mixedhouse;
    AreaValues (){

    }

    public AreaValues(String varea, String hhold, String hsize, String puccahouse, String kutchhouse, String mixedhouse) {
        this.varea = varea;
        this.hhold = hhold;
        this.hsize = hsize;
        this.puccahouse = puccahouse;
        this.kutchhouse = kutchhouse;
        this.mixedhouse = mixedhouse;
    }

    public String getVarea() {
        return varea;
    }

    public String getHhold() {
        return hhold;
    }

    public String getHsize() {
        return hsize;
    }

    public String getPuccahouse() {
        return puccahouse;
    }

    public String getKutchhouse() {
        return kutchhouse;
    }

    public String getMixedhouse() {
        return mixedhouse;
    }
}