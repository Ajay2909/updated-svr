package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;

public class MedicalFacilities extends AppCompatActivity {
    EditText  alhos, ayhos, unhos, homhos, aldisp, aydisp, undisp, homdisp, matchw, mathom, chw,
            hc, phc, phsc, fwc, tbc, nhom, rpmp, smp, chwr, omfac;
    RadioGroup rg1, rg2, rg3;

    DatabaseReference db;
    MedicalValues mv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_facilities);

        alhos = (EditText) findViewById(R.id.allo_hos);
        ayhos = (EditText) findViewById(R.id.ayu_hos);
        unhos = (EditText) findViewById(R.id.una_hos);
        homhos = (EditText) findViewById(R.id.homo_hos);
        aldisp = (EditText) findViewById(R.id.allo_disp);
        aydisp = (EditText) findViewById(R.id.ayu_disp);
        undisp = (EditText) findViewById(R.id.una_disp);
        homdisp = (EditText) findViewById(R.id.homo_disp);
        matchw = (EditText) findViewById(R.id.mat_wel);
        mathom = (EditText) findViewById(R.id.mat_home);
        chw = (EditText) findViewById(R.id.child_wel);
        hc = (EditText) findViewById(R.id.hea_cen);
        phc = (EditText) findViewById(R.id.pri_hea);
        phsc = (EditText) findViewById(R.id.pri_sub);
        fwc = (EditText) findViewById(R.id.fam_wel);
        tbc = (EditText) findViewById(R.id.tb_clinic);
        nhom = (EditText) findViewById(R.id.nur_hom);
        rpmp = (EditText) findViewById(R.id.med_prac);
        smp = (EditText) findViewById(R.id.sub_med_prac);
        chwr = (EditText) findViewById(R.id.com_hea);
        omfac = (EditText) findViewById(R.id.other_med_fac);
        rg1 = (RadioGroup) findViewById(R.id.allopa);
        rg2 = (RadioGroup) findViewById(R.id.mater_wel);
        rg3 = (RadioGroup) findViewById(R.id.prihea);

        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.all_yes) {
                    alhos.setVisibility(View.VISIBLE);
                } else if (i == R.id.all_no) {
                    alhos.setVisibility(View.GONE);
                }
            }
        });

        rg2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.mat_yes){
                    matchw.setVisibility(View.VISIBLE);
                    chw.setVisibility(View.VISIBLE);

                }
                else if(i==R.id.mat_no){
                    matchw.setVisibility(View.GONE);
                    chw.setVisibility(View.GONE);
                }
            }
        });
        rg3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.pri_yes){
                    phc.setVisibility(View.VISIBLE);

                }
                else if(i==R.id.pri_no){
                    phc.setVisibility(View.GONE);
                }
            }
        });
    }


    public void gotoList(View view) {
        String  allo_hos, ayu_hos, una_hos, homo_hos, allo_disp, ayu_disp, una_disp, homo_disp,
                mat_wel, mat_home, child_wel, hea_cen, pri_hea, pri_sub, fam_wel, tb_clinic, nur_hom,
                med_prac, sub_med_prac, com_hea, other_med_fac;
        allo_hos =  alhos.getText().toString();
        ayu_hos =  ayhos.getText().toString();
        una_hos =  unhos.getText().toString();
        homo_hos =  homhos.getText().toString();
        allo_disp =  aldisp.getText().toString();
        ayu_disp =  aydisp.getText().toString();
        una_disp =  undisp.getText().toString();
        homo_disp =  homdisp.getText().toString();
        mat_wel =  matchw.getText().toString();
        mat_home =  mathom.getText().toString();
        child_wel =  chw.getText().toString();
        hea_cen =  hc.getText().toString();
        pri_hea =  phc.getText().toString();
        pri_sub =  phsc.getText().toString();
        fam_wel =  fwc.getText().toString();
        tb_clinic =  tbc.getText().toString();
        nur_hom =  nhom.getText().toString();
        med_prac =  rpmp.getText().toString();
        sub_med_prac =  smp.getText().toString();
        com_hea =  chwr.getText().toString();
        other_med_fac =  omfac.getText().toString();
/*
        int chosenid1 = rg1.getCheckedRadioButtonId();
        switch (chosenid1) {
            case R.id.all_yes:
                break;
            case R.id.all_no:
                break;

        }
        int chosenid2 = rg2.getCheckedRadioButtonId();
        switch (chosenid2) {
            case R.id.mat_yes:
                break;
            case R.id.mat_no:
                break;

        }
        int chosenid3 = rg3.getCheckedRadioButtonId();
        switch (chosenid3) {
            case R.id.pri_yes:
                break;
            case R.id.pri_no:
                break;

        }*/
        mv = new MedicalValues(allo_hos,ayu_hos,una_hos,homo_hos,allo_disp,ayu_disp,
                una_disp,homo_disp,mat_wel,mat_home,child_wel,hea_cen,pri_hea,pri_sub,fam_wel,
                tb_clinic,nur_hom,med_prac,sub_med_prac,com_hea,other_med_fac);
        db.child(getIntent().getStringExtra("state"))
                .child(getIntent().getStringExtra("district"))
                .child(getIntent().getStringExtra("mandal"))
                .child(getIntent().getStringExtra("panchayat"))
                .child(getIntent().getStringExtra("village"))
                .setValue(mv);
        Intent i = new Intent(this, ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        alhos.setText("");
        ayhos.setText("");
        unhos.setText("");
        homhos.setText("");
        aldisp.setText("");
        aydisp.setText("");
        undisp.setText("");
        homdisp.setText("");
        chw.setText("");
        hc.setText("");
        phc.setText("");
        phsc.setText("");
        fwc.setText("");
        tbc.setText("");
        nhom.setText("");
        rpmp.setText("");
        smp.setText("");
        omfac.setText("");
        rg1.clearCheck();
        rg2.clearCheck();
        rg3.clearCheck();
        alhos.setVisibility(View.GONE);
        phc.setVisibility(View.GONE);
        matchw.setVisibility(View.GONE);
        chw.setVisibility(View.GONE);

    }

    public void goBack(View view) {
        Intent i = new Intent(this, ListOfDomains.class);
        startActivity(i);

    }
}
