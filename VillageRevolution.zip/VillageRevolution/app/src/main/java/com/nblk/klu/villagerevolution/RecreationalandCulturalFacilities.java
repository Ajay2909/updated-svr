package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RecreationalandCulturalFacilities extends AppCompatActivity {
    RadioGroup r,r1,r2,r3;
    EditText hhold,cinevideo,sports,sta_audi;
    RecreationValue recv;


    DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recreationaland_cultural_facilities);
        db= FirebaseDatabase.getInstance().getReference("India");

        hhold=findViewById(R.id.hhc);
        cinevideo=findViewById(R.id.chvh);
        sports=findViewById(R.id.sc);
        sta_audi=findViewById(R.id.sa);
        r=findViewById(R.id.trg);
        r1=findViewById(R.id.crg);
        r2=findViewById(R.id.srg);
        r3=findViewById(R.id.sarg);
        r.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.tyes)
                    hhold.setVisibility(View.VISIBLE);
                else if(i==R.id.tno)
                    hhold.setVisibility(View.GONE);
            }
        });
        r1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.cyes)
                    cinevideo.setVisibility(View.VISIBLE);
                else if(i==R.id.cno)
                    cinevideo.setVisibility(View.GONE);
            }
        });
        r2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.syes)
                    sports.setVisibility(View.VISIBLE);
                else if(i==R.id.sno)
                    sports.setVisibility(View.GONE);
            }
        });
        r3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.sayes)
                    sta_audi.setVisibility(View.VISIBLE);
                else if(i==R.id.sano)
                    sta_audi.setVisibility(View.GONE);
            }
        });

    }

    public void gotoList(View view) {
        String household,cine_video,sport_club,sport_club_ava;
        int chooseid,chooseid1,chooseid2,chooseid3;
        household=hhold.getText().toString();
        cine_video=cinevideo.getText().toString();
        sport_club=sports.getText().toString();
        sport_club_ava=sta_audi.getText().toString();
        chooseid=r.getCheckedRadioButtonId();
        chooseid1=r1.getCheckedRadioButtonId();
        chooseid2=r2.getCheckedRadioButtonId();
        chooseid3=r3.getCheckedRadioButtonId();
        switch(chooseid){
            case R.id.tyes:
                break;
            case R.id.tno:
                break;
        }
        switch (chooseid1){
            case R.id.cyes:
                break;
            case R.id.cno:
                break;
        }
        switch(chooseid2){
            case R.id.syes:
                break;
            case R.id.sno:
                break;
        }
        switch(chooseid3){
            case R.id.sayes:
                break;
            case R.id.sano:
                break;
        }
        recv = new RecreationValue(household,cine_video,sport_club,sport_club_ava);
        db.child(getIntent().getStringExtra("state")).child(getIntent().getStringExtra("district")).child(getIntent().getStringExtra("mandal")).child(getIntent().getStringExtra("panchayat")).child(getIntent().getStringExtra("village")).child("RecreationalandCulturalfacilities").setValue(recv);

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void resetAll(View view) {
        hhold.setText("");
        cinevideo.setText("");
        sports.setText("");
        sta_audi.setText("");
        r.clearCheck();
        r1.clearCheck();
        r2.clearCheck();
        r3.clearCheck();
    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }
}
