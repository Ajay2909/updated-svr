package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class DrinkingValues {

    String safe,tap,well,tank,tube,handp,river,lake,spring,canal,otherw;
    DrinkingValues(String med_fac, String allo_hos, String ayu_hos, String una_hos, String homo_hos, String allo_disp, String ayu_disp, String una_disp, String homo_disp, String mat_wel, String mat_home, String child_wel, String hea_cen, String pri_hea, String pri_sub, String fam_wel, String tb_clinic, String nur_hom, String med_prac, String sub_med_prac, String com_hea, String other_med_fac){

    }
    public DrinkingValues(String safe, String tap, String well, String tank, String tube,
                          String handp, String river, String lake, String spring, String canal, String otherw) {
        this.safe = safe;
        this.tap = tap;
        this.well = well;
        this.tank = tank;
        this.tube = tube;
        this.handp = handp;
        this.river = river;
        this.lake = lake;
        this.spring = spring;
        this.canal = canal;
        this.otherw = otherw;
    }

    public String getSafe() {
        return safe;
    }

    public void setSafe(String safe) {
        this.safe = safe;
    }

    public String getTap() {
        return tap;
    }

    public void setTap(String tap) {
        this.tap = tap;
    }

    public String getWell() {
        return well;
    }

    public void setWell(String well) {
        this.well = well;
    }

    public String getTank() {
        return tank;
    }

    public void setTank(String tank) {
        this.tank = tank;
    }

    public String getTube() {
        return tube;
    }

    public void setTube(String tube) {
        this.tube = tube;
    }

    public String getHandp() {
        return handp;
    }

    public void setHandp(String handp) {
        this.handp = handp;
    }

    public String getRiver() {
        return river;
    }

    public void setRiver(String river) {
        this.river = river;
    }

    public String getLake() {
        return lake;
    }

    public void setLake(String lake) {
        this.lake = lake;
    }

    public String getSpring() {
        return spring;
    }

    public void setSpring(String spring) {
        this.spring = spring;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getOtherw() {
        return otherw;
    }

    public void setOtherw(String otherw) {
        this.otherw = otherw;
    }
}
