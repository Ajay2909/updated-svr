package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

class RecreationValue {
    public RecreationValue(String household, String cine_video, String sport_club, String sport_club_ava) {

    }
}
