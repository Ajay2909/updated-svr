package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class PowerValues {
    String busi_con,no_street,comm_esta;
    PowerValues (){

    }

    public PowerValues(String busi_con, String no_street, String comm_esta) {
        this.busi_con = busi_con;
        this.no_street = no_street;
        this.comm_esta = comm_esta;
    }

    public String getBusi_con() {
        return busi_con;
    }

    public String getNo_street() {
        return no_street;
    }

    public String getComm_esta() {
        return comm_esta;
    }
}