package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class AreaDetails extends AppCompatActivity {

    EditText varea,hhold,hsize,puccahouse,kutchhouse,mixedhouse;
    AreaValues av;
    DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_details);

        varea=(EditText)findViewById(R.id.villagearea);
        hhold=(EditText)findViewById(R.id.household);
        hsize=(EditText)findViewById(R.id.housesize);
        puccahouse=(EditText)findViewById(R.id.pucca);
        kutchhouse=(EditText)findViewById(R.id.kutcha);
        mixedhouse=(EditText)findViewById(R.id.mixed);
        db= FirebaseDatabase.getInstance().getReference("India");


    }

    public void gotoList(View view) {
        String villagearea,housesize;
        String household,pucca,kutcha,mixed;
        villagearea="0"+varea.getText().toString().toLowerCase();
        household="0"+hhold.getText().toString().toLowerCase();
        housesize="0"+hsize.getText().toString().toLowerCase();
        pucca="0"+puccahouse.getText().toString().toLowerCase();
        kutcha="0"+kutchhouse.getText().toString().toLowerCase();
        mixed="0"+mixedhouse.getText().toString().toLowerCase();
        av=new AreaValues(villagearea,household,housesize,pucca,kutcha,mixed);

        db.child(getIntent().getStringExtra("state")).child(getIntent().getStringExtra("district")).child(getIntent().getStringExtra("mandal")).child(getIntent().getStringExtra("panchayat")).child(getIntent().getStringExtra("village")).child("AreaDetails").setValue(av);
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        varea.setText("");
        hhold.setText("");
        hsize.setText("");
        puccahouse.setText("");
        kutchhouse.setText("");
        mixedhouse.setText("");
    }
}