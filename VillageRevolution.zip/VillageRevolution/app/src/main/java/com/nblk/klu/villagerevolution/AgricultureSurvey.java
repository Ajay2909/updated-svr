package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AgricultureSurvey extends AppCompatActivity {

    EditText foland,plland,gocanals,pvcanals,wellw,welle,twoe,
            twe,tank,river,lake,wfs,others,tias,uias,cws,anafculs;
    AgriNew1 an;
    DatabaseReference db1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agriculture_survey);

        db1= FirebaseDatabase.getInstance().getReference("India");

        foland=findViewById(R.id.fland);
        plland=findViewById(R.id.pland);
        gocanals=findViewById(R.id.govcanals);
        pvcanals=findViewById(R.id.pvtcanals);
        wellw=findViewById(R.id.wellwoe);
        welle=findViewById(R.id.wellwe);
        twoe=findViewById(R.id.twwoe);
        twe=findViewById(R.id.twwe);
        tank=findViewById(R.id.tanks);
        river=findViewById(R.id.rivers);
        lake=findViewById(R.id.lakes);
        wfs=findViewById(R.id.wf);
        others=findViewById(R.id.other);
        tias=findViewById(R.id.tia);
        uias=findViewById(R.id.uia);
        cws=findViewById(R.id.cw);
        anafculs=findViewById(R.id.anafcul);


    }
    public void gotoList(View view) {
        String fland;
        String pland;
        String other;
        String tia;
        String uia;
        String cw;

        String govcanals,pvtcanals,wellwoe,wellwe,twwoe,twwe,tanks,rivers,lakes,wf,anafcul;
        //resetAll(view);
        fland="0"+foland.getText().toString();
        pland= "0"+plland.getText().toString();
        govcanals= "0"+gocanals.getText().toString();
        pvtcanals= "0"+pvcanals.getText().toString();
        wellwoe= "0"+wellw.getText().toString();
        wellwe= "0"+welle.getText().toString();
        twwoe= "0"+twoe.getText().toString();
        twwe= "0"+twe.getText().toString();
        tanks= "0"+tank.getText().toString();
        rivers= "0"+river.getText().toString();
        lakes= "0"+lake.getText().toString();
        wf= "0"+wfs.getText().toString();
        other= "0"+others.getText().toString();
        tia= "0"+tias.getText().toString();
        uia= "0"+uias.getText().toString();
        cw= "0"+cws.getText().toString();
        anafcul= "0"+anafculs.getText().toString();

        /*String foland,plland,gocanals,pvcanals,wellw,welle,twoe,
                twe,tank,river,lake,wfs,others,tias,uias,cws,anafculs;*/

        an = new AgriNew1(fland,pland,govcanals,pvtcanals,wellwoe,wellwe,twwoe,twwe,tanks,rivers,lakes,wf,other,tia,uia,cw,anafcul);

        db1.child(getIntent().getStringExtra("state")).child(getIntent().getStringExtra("district")).child(getIntent().getStringExtra("mandal")).child(getIntent().getStringExtra("panchayat")).child(getIntent().getStringExtra("village")).child("AgricultureSurvey").setValue(an);

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        foland.setText("");
        plland.setText("");
        gocanals.setText("");
        pvcanals.setText("");
        wellw.setText("");
        welle.setText("");
        twoe.setText("");
        twe.setText("");
        tank.setText("");
        river.setText("");
        lake.setText("");
        wfs.setText("");
        others.setText("");
        tias.setText("");
        uias.setText("");
        cws.setText("");
        anafculs.setText("");

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
