package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EducationFacilities extends AppCompatActivity {
    EditText cattend,sgchild,sprimary,disnprimary,msch,disnmsch,secsch,disnsecsch,col,sssch,adlcls,
            colavrng,indschl,tsch,oedsch;

    EducationNew en;
    DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education_facilities);
        db= FirebaseDatabase.getInstance().getReference("India");

        cattend=(EditText)findViewById(R.id.childatten);
        sgchild=(EditText)findViewById(R.id.schoolgoing);
        sprimary=(EditText)findViewById(R.id.schprimary);
        disnprimary=(EditText)findViewById(R.id.distschpri);
        msch=(EditText)findViewById(R.id.schmid);
        disnmsch=(EditText)findViewById(R.id.distschmid);
        secsch=(EditText)findViewById(R.id.schsec);
        disnsecsch=(EditText)findViewById(R.id.distschsec);
        col=(EditText)findViewById(R.id.clg);
        sssch=(EditText)findViewById(R.id.srsecsch);
        adlcls=(EditText)findViewById(R.id.adultlit);
        colavrng=(EditText)findViewById(R.id.clgrange);
        indschl=(EditText)findViewById(R.id.indsch);
        tsch=(EditText)findViewById(R.id.traisch);
        oedsch=(EditText)findViewById(R.id.edusch);


    }

    public void gotoList(View view) {
        String childatten,schoolgoing,schprimary,schmid,schsec,
                clg,srsecsch,adultlit,clgrange,indsch,traisch,edusch;
        String distschmid,distschpri,distschsec;
        childatten="0"+cattend.getText().toString();
        schoolgoing="0"+sgchild.getText().toString();
        schprimary="0"+sprimary.getText().toString();
        distschpri="0"+disnprimary.getText().toString();
        schmid="0"+msch.getText().toString();
        distschmid="0"+disnmsch.getText().toString();
        schsec="0"+secsch.getText().toString();
        distschsec="0"+disnsecsch.getText().toString();
        clg="0"+col.getText().toString();
        srsecsch="0"+sssch.getText().toString();
        adultlit="0"+adlcls.getText().toString();
        clgrange="0"+colavrng.getText().toString();
        indsch="0"+indschl.getText().toString();
        traisch="0"+tsch.getText().toString();
        edusch="0"+oedsch.getText().toString();

        en= new EducationNew(childatten,schoolgoing,schprimary,schmid,schsec,clg,srsecsch,adultlit,clgrange,indsch,traisch,edusch,distschmid,distschpri,distschsec);
        db.child(getIntent().getStringExtra("state")).child(getIntent().getStringExtra("district")).child(getIntent().getStringExtra("mandal")).child(getIntent().getStringExtra("panchayat")).child(getIntent().getStringExtra("village")).child("EdicationalFacilities").setValue(en);
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        cattend.setText("");
        sgchild.setText("");
        sprimary.setText("");
        disnprimary.setText("");
        msch.setText("");
        disnmsch.setText("");
        secsch.setText("");
        disnsecsch.setText("");
        col.setText("");
        sssch.setText("");
        adlcls.setText("");
        colavrng.setText("");
        indschl.setText("");
        tsch.setText("");
        oedsch.setText("");

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}


