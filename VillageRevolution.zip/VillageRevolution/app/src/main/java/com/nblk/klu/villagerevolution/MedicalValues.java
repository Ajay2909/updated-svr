package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class MedicalValues {
    String allohos,ayurhos,unhos,homhos,allodisp,ayurdisp,homdisp,undisp,healthc,matchwelfc,chwc,
            mathome,fwelc,prihealthc,prihsubc,nurshom,tbcli,regpri,othermed,medfac,submedprac,comhw;
    MedicalValues(){

    }
    public MedicalValues(String allo_hos, String ayu_hos, String una_hos,
                         String homo_hos, String allo_disp, String ayu_disp, String una_disp,
                         String homo_disp, String mat_wel, String mat_home, String child_wel,
                         String hea_cen, String pri_hea, String pri_sub, String fam_wel,
                         String tb_clinic, String nur_hom, String med_prac, String sub_med_prac,
                         String com_hea, String other_med_fac) {
    }

    public String getAllohos() {
        return allohos;
    }

    public void setAllohos(String allohos) {
        this.allohos = allohos;
    }

    public String getAyurhos() {
        return ayurhos;
    }

    public void setAyurhos(String ayurhos) {
        this.ayurhos = ayurhos;
    }

    public String getUnhos() {
        return unhos;
    }

    public void setUnhos(String unhos) {
        this.unhos = unhos;
    }

    public String getHomhos() {
        return homhos;
    }

    public void setHomhos(String homhos) {
        this.homhos = homhos;
    }

    public String getAllodisp() {
        return allodisp;
    }

    public void setAllodisp(String allodisp) {
        this.allodisp = allodisp;
    }

    public String getAyurdisp() {
        return ayurdisp;
    }

    public void setAyurdisp(String ayurdisp) {
        this.ayurdisp = ayurdisp;
    }

    public String getHomdisp() {
        return homdisp;
    }

    public void setHomdisp(String homdisp) {
        this.homdisp = homdisp;
    }

    public String getUndisp() {
        return undisp;
    }

    public void setUndisp(String undisp) {
        this.undisp = undisp;
    }

    public String getHealthc() {
        return healthc;
    }

    public void setHealthc(String healthc) {
        this.healthc = healthc;
    }

    public String getMatchwelfc() {
        return matchwelfc;
    }

    public void setMatchwelfc(String matchwelfc) {
        this.matchwelfc = matchwelfc;
    }

    public String getChwc() {
        return chwc;
    }

    public void setChwc(String chwc) {
        this.chwc = chwc;
    }

    public String getMathome() {
        return mathome;
    }

    public void setMathome(String mathome) {
        this.mathome = mathome;
    }

    public String getFwelc() {
        return fwelc;
    }

    public void setFwelc(String fwelc) {
        this.fwelc = fwelc;
    }

    public String getPrihealthc() {
        return prihealthc;
    }

    public void setPrihealthc(String prihealthc) {
        this.prihealthc = prihealthc;
    }

    public String getPrihsubc() {
        return prihsubc;
    }

    public void setPrihsubc(String prihsubc) {
        this.prihsubc = prihsubc;
    }

    public String getNurshom() {
        return nurshom;
    }

    public void setNurshom(String nurshom) {
        this.nurshom = nurshom;
    }

    public String getTbcli() {
        return tbcli;
    }

    public void setTbcli(String tbcli) {
        this.tbcli = tbcli;
    }

    public String getRegpri() {
        return regpri;
    }

    public void setRegpri(String regpri) {
        this.regpri = regpri;
    }

    public String getOthermed() {
        return othermed;
    }

    public void setOthermed(String othermed) {
        this.othermed = othermed;
    }

    public String getMedfac() {
        return medfac;
    }

    public void setMedfac(String medfac) {
        this.medfac = medfac;
    }

    public String getSubmedprac() {
        return submedprac;
    }

    public void setSubmedprac(String submedprac) {
        this.submedprac = submedprac;
    }

    public String getComhw() {
        return comhw;
    }

    public void setComhw(String comhw) {
        this.comhw = comhw;
    }
}

