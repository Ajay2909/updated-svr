package com.nblk.klu.villagerevolution;

/**
 * Created by bhavna on 9/15/2018.
 */

public class PostTelegraphValues {
    String post,tel,posttele,tele;
    PostTelegraphValues(){}

    public PostTelegraphValues(String post, String tel, String tele) {
        this.post = post;
        this.tel = tel;
        this.posttele = posttele;
        this.tele = tele;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPosttele() {
        return posttele;
    }

    public void setPosttele(String posttele) {
        this.posttele = posttele;
    }

    public String getTele() {
        return tele;
    }

    public void setTele(String tele) {
        this.tele = tele;
    }
}
