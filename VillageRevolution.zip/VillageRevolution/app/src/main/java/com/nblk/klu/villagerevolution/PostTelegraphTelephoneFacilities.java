package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;

public class PostTelegraphTelephoneFacilities extends AppCompatActivity {
    EditText pstoff,tele,tel;
    LinearLayout lla;
    RadioGroup rg5,rg6;
    DatabaseReference db;
    PostTelegraphValues pttv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_telegraph_telephone_facilities);
        pstoff=(EditText)findViewById(R.id.postoff);
        tele=(EditText)findViewById(R.id.telegr);
        lla=findViewById(R.id.linlay);
        tel=(EditText)findViewById(R.id.telep);
        rg5=(RadioGroup)findViewById(R.id.radioGroup5);
        rg6=(RadioGroup)findViewById(R.id.radioGroup6);
        rg5.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.pttavailyes)
                    lla.setVisibility(View.VISIBLE);
                else if(i==R.id.pttavailno)
                    lla.setVisibility(View.GONE);
            }
        });
    }

    public void gotoList(View view) {
        String  postoff,telegr,postandteleg,telep;
        postoff=pstoff.getText().toString();
        telegr=tele.getText().toString();
        telep=tel.getText().toString();
        /*int choosenId=rg5.getCheckedRadioButtonId();
        switch(choosenId)
        {
            case R.id.pttavailyes:
                break;
            case R.id.pttavailno:
                break;
        }
        int choosenId1=rg6.getCheckedRadioButtonId();
        switch(choosenId1)
        {
            case R.id.availinteyes:
                break;
            case R.id.availinteno:
                break;
        }*/
        pttv = new PostTelegraphValues(postoff,telegr,telep);
        db.child(getIntent().getStringExtra("state"))
                .child(getIntent().getStringExtra("district"))
                .child(getIntent().getStringExtra("mandal"))
                .child(getIntent().getStringExtra("panchayat"))
                .child(getIntent().getStringExtra("village"))
                .setValue(pttv);
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        pstoff.setText("");
        tele.setText("");
        tel.setText("");
        rg5.clearCheck();
        rg6.clearCheck();
        lla.setVisibility(View.GONE);

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}