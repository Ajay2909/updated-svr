package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Bankingfacilities extends AppCompatActivity {
    EditText cmbnk,cpbnk;
    RadioGroup cmbg,rg;

    DatabaseReference db;
    BankingValues banv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bankingfacilities);
        cmbnk=(EditText)findViewById(R.id.combank);
        cpbnk=(EditText)findViewById(R.id.coopbank);
        cmbg=(RadioGroup)findViewById(R.id.combankg);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
        db= FirebaseDatabase.getInstance().getReference("India");

        cmbg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
              if (i==R.id.combankyes){
                  cmbnk.setVisibility(View.VISIBLE);
              }
              else if (i==R.id.combankno){
                  cmbnk.setVisibility(View.GONE);
              }
            }
        });
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i==R.id.coopyes){
                    cpbnk.setVisibility(View.VISIBLE);
                }
                else if (i==R.id.coopno){
                    cpbnk.setVisibility(View.GONE);
                }
            }
        });

    }
    public void gotoList(View view) {
        String combank,coopbank;
        combank=cmbnk.getText().toString();
        coopbank=cpbnk.getText().toString();
        /*int choosenId=cmbg.getCheckedRadioButtonId();
        switch(choosenId)
        {
            case R.id.combankyes:
                cmbnk.setVisibility(View.VISIBLE);
                break;
            case R.id.combankno:
                cmbnk.setVisibility(View.INVISIBLE);
                break;
        }
        int choosenId1=rg.getCheckedRadioButtonId();
        switch(choosenId1)
        {
            case R.id.coopyes:
                cpbnk.setVisibility(View.VISIBLE);
                break;
            case R.id.coopno:
                cpbnk.setVisibility(View.INVISIBLE);
                break;
        }
        */
        banv = new BankingValues(combank,coopbank);
        db.child(getIntent().getStringExtra("state")).child(getIntent().getStringExtra("district")).child(getIntent().getStringExtra("mandal")).child(getIntent().getStringExtra("panchayat")).child(getIntent().getStringExtra("village")).child("BankingFacilities").setValue(banv);
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        cmbnk.setText("");
        cmbnk.setVisibility(View.GONE);
        cpbnk.setVisibility(View.GONE);
        cpbnk.setText("");
        rg.clearCheck();
        cmbg.clearCheck();


    }
}
