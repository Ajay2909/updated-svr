package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;

public class MostImportantCommoditiesManufactured extends AppCompatActivity {

    EditText c1,c2,c3;
    DatabaseReference db;
    MostImportantValues miv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_most_important_commodities_manufactured);

        c1=(EditText)findViewById(R.id.income);
        c2=(EditText)findViewById(R.id.mic2);
        c3=(EditText)findViewById(R.id.mic3);

    }
    public void gotoList(View view) {
        String mic1,mic2,mic3;
        mic1=" "+c1.getText().toString().toLowerCase();
        mic2=" "+c2.getText().toString().toLowerCase();
        mic3=" "+c3.getText().toString().toLowerCase();
        miv = new MostImportantValues(mic1,mic2,mic3);
        db.child(getIntent().getStringExtra("state"))
                .child(getIntent().getStringExtra("district"))
                .child(getIntent().getStringExtra("mandal"))
                .child(getIntent().getStringExtra("panchayat"))
                .child(getIntent().getStringExtra("village"))
                .setValue(miv);
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void resetAll(View view) {

        c1.setText("");
        c2.setText("");
        c3.setText("");
    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}

